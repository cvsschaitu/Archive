require.config({
    waitSeconds: 60,
    paths: {
        domReady:'lib/domReady',
        angular: 'lib/angular' ,
        'angular-ui-router': 'lib/angular-ui-router',
        ng: 'lib/ng'
    },
    shim:{
        'angular-ui-router': ['angular'],
        'angular': {
            exports: 'angular'
        }
    },
    deps: [
        'angular-ui-router',
        './bootstrap'
    ]
});

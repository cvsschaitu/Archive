define(['views/views'],
    function (app){
        return app.controller('homecntl',function($scope){
            $scope.homeMessage = 'Welcome Home.';
        }) ;
    });
define([
    'require',
    'angular',
    'family',
    'routes'
], function (require, angular) {
    require(['domReady!'], function (document) {
        angular.bootstrap(document, ['family'])
    })
});

define(['views/views'],
function (app){
   return app.controller('aboutCntl',function($scope){
       $scope.aboutMessage = 'This is all bout About ..When you click on About link.';
   }) ;
});

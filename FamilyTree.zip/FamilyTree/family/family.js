define ([
    'angular',
    'angular-ui-router',
    './views/views'
],function(angular){
    return angular.module('family',['ui.router'])
});


